package sofuni.exam.util;


public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
