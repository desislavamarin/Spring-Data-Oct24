insert into volcanoes (id, name, elevation, volcano_type, is_active, last_eruption, country_id)
values    (1, 'Mount Vesuvius', 1281, 'STRATOVOLCANO', true, '2021-01-01', 1),
          (2, 'Mauna Loa', 4169, 'SHIELD_VOLCANO', true, '2022-03-15', 2),
          (3, 'Mount Fuji', 3776, 'STRATOVOLCANO', false, '1707-12-16', 3),
          (4, 'Mount St. Helens', 2549, 'STRATOVOLCANO', false, '1980-05-18', 4);